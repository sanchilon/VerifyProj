# Contributing to OpenVerify

Want to contribute to OpenVerify? There are a few things you need to know.  
